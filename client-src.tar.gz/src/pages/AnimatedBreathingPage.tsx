import AnimatedBlowfish from '../components/AnimatedBlowfish';

export default function AnimatedBreathingPage() {
  return <AnimatedBlowfish />;
}
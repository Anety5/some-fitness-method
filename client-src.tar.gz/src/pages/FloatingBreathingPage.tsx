import FloatingBlowfish from '../components/FloatingBlowfish';

export default function FloatingBreathingPage() {
  return <FloatingBlowfish />;
}
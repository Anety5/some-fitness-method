import StrengthTraining from "@/components/StrengthTraining";

export default function StrengthTrainingPage() {
  return <StrengthTraining />;
}
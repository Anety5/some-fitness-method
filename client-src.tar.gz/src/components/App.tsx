import FloatingBlowfish from './FloatingBlowfish';

export default function App() {
  return <FloatingBlowfish />;
}